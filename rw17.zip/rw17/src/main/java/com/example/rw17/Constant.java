package com.example.rw17;

public class Constant {
    //http://v.juhe.cn/toutiao/index?type=keji&key=807f10d5da886d846acdde0d7c34024d
    public static final String KEY="807f10d5da886d846acdde0d7c34024d";
    public static final String KEJI_URL="http://v.juhe.cn/toutiao/index?type=keji&key="+KEY+"";
    public static final String JUNSHI_URL="http://v.juhe.cn/toutiao/index?type=junshi&key="+KEY+"";
}
